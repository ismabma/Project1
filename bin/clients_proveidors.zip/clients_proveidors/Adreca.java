package clients_proveidors;

public class Adreca {
    private int cp;
    private String poblacio;
    private String provincia;
    private String domicili;

    public Adreca() {
    }

    public Adreca(int cp, String domicili, String poblacio, String provincia){
            this.cp = cp;
            this.domicili = domicili;
            this.poblacio = poblacio;
            this.provincia = provincia;
    }

    public void setCp(int cp) {
        this.cp = cp;
    }

    public void setDomicili(String domicili) {
        this.domicili = domicili;
    }
    public void setPoblacio(String poblacio) {
        this.poblacio = poblacio;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public int getCp() {
        return cp;
    }

    public String getDomicili() {
        return domicili;
    }

    public String getPoblacio() {
        return poblacio;
    }

    public String getProvincia() {
        return provincia;
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return super.toString();
    }
    

}
