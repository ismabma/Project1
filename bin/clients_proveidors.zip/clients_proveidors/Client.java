package clients_proveidors;

import java.time.LocalDate;

public class Client extends Persona {
    public Client(int idpersona, String dNI, String nom, String cognoms, LocalDate data_naixement, String email,
            int tlf, Adreca adreca) {
        super(idpersona, dNI, nom, cognoms, data_naixement, email, tlf, adreca);
    }

    public Client(int idpersona, String dNI, String nom, String cognoms) {
        super(idpersona, dNI, nom, cognoms);
    }
}
