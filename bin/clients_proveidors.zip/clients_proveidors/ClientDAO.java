package clients_proveidors;

import java.time.LocalDate;
import java.util.HashMap;

public class ClientDAO {
    private HashMap<Integer, Client> clients = new HashMap<Integer, Client>();

    public void addClient(Integer idpersona, String dNI, String nom, String cognoms, LocalDate data_naixement, String email, int tlf, Adreca adreca) {
        Client c = new Client(idpersona, dNI, nom, cognoms, data_naixement, email, tlf, adreca);
        if(clients.containsKey(idpersona) == false){
                this.clients.put(idpersona, c);
        }
    }

    public void updateClient(Integer idpersona, String dNI, String nom, String cognoms, LocalDate data_naixement, String email, int tlf, Adreca adreca) {
        Client c = new Client(idpersona, dNI, nom, cognoms, data_naixement, email, tlf, adreca);
        if(clients.containsKey(idpersona) == true){
                this.clients.put(idpersona, c);
        }
    }

    public boolean searchClient(Integer idpersona) {
        return this.clients.containsKey(idpersona);
    }

    public void deleteClient(Integer idpersona) {
        this.clients.remove(idpersona);
    }

    public String showClients() {
        return this.clients.toString();
    }

    public String showClient(Integer idpersona){
        return this.clients.get(idpersona).toString();
    }
}
