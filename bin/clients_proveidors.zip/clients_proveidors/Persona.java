package clients_proveidors;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public abstract class Persona {
    private Integer idpersona;
    private String DNI;
    private String nom;
    private String cognoms;
    private LocalDate data_naixement;
    private String Email;
    private int tlf;
    private Adreca adreca;
    static int num_persones;

    //Contructor 1
    public Persona(Integer idpersona, String dNI, String nom, String cognoms) {
        if(isValid(dNI, nom, cognoms)){
            this.idpersona = idpersona;
            this.DNI = dNI;
            this.nom = nom;
            this.cognoms = cognoms;
            num_persones++;
        }
    }

    //Contructor 2
    public Persona(Integer idpersona, String dNI, String nom, String cognoms, LocalDate data_naixement, String email, int tlf, Adreca adreca) {
        if(isValid(dNI, nom, cognoms)){
            this.idpersona = idpersona;
            this.DNI = dNI;
            this.nom = nom;
            this.cognoms = cognoms;
            this.data_naixement = data_naixement;
            this.Email = email;
            this.tlf = tlf;
            this.adreca = adreca;
            num_persones++;
        }
    }


    //Setters
    public void setAdreca(Adreca adreca) {
        this.adreca = adreca;
    }

    public void setCognoms(String cognoms) {
        this.cognoms = cognoms;
    }

    public void setDNI(String dNI) {
        DNI = dNI;
    }

    public void setData_naixement(LocalDate data_naixement) {
        this.data_naixement = data_naixement;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public void setIdpersona(Integer idpersona) {
        this.idpersona = idpersona;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setTlf(int tlf) {
        this.tlf = tlf;
    }

    
    //Getters
    public Adreca getAdreca() {
        return adreca;
    }

    public String getCognoms() {
        return cognoms;
    }

    public String getDNI() {
        return DNI;
    }

    public LocalDate getData_naixement() {
        return data_naixement;
    }

    public String getEmail() {
        return Email;
    }

    public int getIdpersona() {
        return idpersona;
    }

    public String getNom() {
        return nom;
    }

    public int getTlf() {
        return tlf;
    }

    public int getNumPersones(){
        return num_persones;
    }

    public int getEdad(){
        return (int) ChronoUnit.YEARS.between(this.data_naixement, LocalDate.now());
    }

    public static long diferenciaEdad(Persona p1, Persona p2){
        return ChronoUnit.YEARS.between(p1.data_naixement, p2.data_naixement);
    }

    @Override
    public String toString() {
        return "ID: " + this.idpersona + "\n" + 
        "DNI: " + this.DNI + "\n" + 
        "Email: " + this.Email + "\n" + 
        "Cognoms: " + this.cognoms + "\n" + 
        "Nom: " + this.nom + "\n" + 
        "Telefon: " + this.tlf + "\n" + 
        "Adreca: " + this.adreca.toString() + "\n" +
        "Edat: " + this.getEdad() + "\n";
    }

    private boolean isValid(String dNI, String nom, String cognoms){
        if(dNI != null && nom != null && cognoms != null){
            return true;
        } else{
            return false;
        }
    }


}
