package clients_proveidors;

import java.time.LocalDate;
import java.util.HashMap;

public class SupplierDAO {
    private HashMap<Integer, Supplier> suppliers = new HashMap<Integer, Supplier>();

    public void addSupplier(Integer idpersona, String dNI, String nom, String cognoms, LocalDate data_naixement, String email, int tlf, Adreca adreca) {
        Supplier s = new Supplier(idpersona, dNI, nom, cognoms, data_naixement, email, tlf, adreca);
        if(suppliers.containsKey(idpersona) == false){
                this.suppliers.put(idpersona, s);
        }
    }

    public void updateSupplier(Integer idpersona, String dNI, String nom, String cognoms, LocalDate data_naixement, String email, int tlf, Adreca adreca) {
        Supplier s = new Supplier(idpersona, dNI, nom, cognoms, data_naixement, email, tlf, adreca);
        if(suppliers.containsKey(idpersona) == true){
                this.suppliers.put(idpersona, s);
        }
    }

    public boolean searchSupplier(Integer idpersona) {
        return this.suppliers.containsKey(idpersona);
    }

    public void deleteSupplier(Integer idpersona) {
        this.suppliers.remove(idpersona);
    }

    public String showSuppliers() {
        return this.suppliers.toString();
    }

    public String showSupplier(Integer idpersona){
        return this.suppliers.get(idpersona).toString();
    }
}
