package coleccions;

public interface Identificable {
    public Integer getId();
}
