package errec;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class AbstractDAO<T extends Identificable> implements Persistable<T> {
    private HashMap<Integer, T> map = new HashMap<>();

    public HashMap<Integer, T> getMap() {
        return map;
    }

    public void save(T t) {
        if (!map.containsKey(t.getId())) {
            this.map.put(t.getId(), t);
        }
    }

    public List<T> getAll(){
        List<T> list = new ArrayList<>();
        for (Integer key: map.keySet()) {
            list.add(map.get(key));
        }
        return list;
    }

    public void update(T t) {
        if (map.containsKey(t.getId())) {
            this.map.put(t.getId(), t);
        }
    }

    public T get(Integer id) {
        return this.map.get(id);
    }

    public Integer getLastId() {
        Integer bigger=0;
        for (Integer key: map.keySet()) {
            if(bigger < key) bigger = key;
        }
        return bigger;
    }

    public void delete(Integer id) {
        this.map.remove(id);
    }
}
