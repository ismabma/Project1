package errec;

public interface Identificable {
    public Integer getId();
}
