package errec;

import java.util.ArrayList;

public final class Pack extends Product {
    private ArrayList<Integer> products;
    private int discount;

    public Pack(Integer idproduct, String name, double sellPrice, int stock, ArrayList<Integer> productss,
            int discoun) {
        super(idproduct, name, sellPrice, stock);
        this.products = productss;
        this.discount = discoun;
    }

    public Pack(Integer idproduct, String name, double sellPrice, int stock, int discount) {
        super(idproduct, name, sellPrice, stock);
        this.products = new ArrayList<Integer>();
        this.discount = discount;
    }

    public void addProduct(Integer id) {
        this.products.add(id);
    }

    public void deleteProduct(Integer id) {
        for (int i = 0; i <= this.products.size(); i++) {
            if (this.products.get(i).compareTo(id) == 0) {
                this.products.remove(i);
            }
        }
    }

    public int getDiscount() {
        return discount;
    }

    public void setDiscount(int discount) {
        this.discount = discount;
    }

    @Override
    public String toString() {
        return "Producte [idproducte=" + super.getId() + ", nom=" + super.getName() + ", preuVenda=" + super.getpriceSell() + ", stock=" + super.getStock() +
        "discount=" + discount + ", products=" + products.toString()+ "]";
    }
    
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Pack) {
            Pack p = (Pack) obj;
            for (int i = 0; i <= this.products.size(); i++) {
                if (this.products.get(i).compareTo(p.getId()) != 0) {
                    return false;
                }
            }

            return true;
        }
        return false;
    }

}
