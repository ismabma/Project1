package fitxers;

public interface Identificable {
    public Integer getId();
}
