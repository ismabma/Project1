package fitxers;

public class Product implements Identificable  {
    private Integer idproduct;
    private String name;
    private double priceSell;
    private int stock;

    public Product(Integer idproducte, String nam, double priceSel, int stock) {
        this.idproduct = idproducte;
        this.name = nam;
        this.priceSell = priceSel;
        this.stock = stock;
    }

    public Integer getId() {
        return idproduct;
    }

    public void setId(Integer idproducte) {
        this.idproduct = idproducte;
    }

    public String getName() {
        return name;
    }

    public void setName(String nam) {
        this.name = nam;
    }

    public double getpriceSell() {
        return priceSell;
    }

    public void setpriceSell(double priceSel) {
        this.priceSell = priceSel;
    }

    public int getStock() {
        return stock;
    }

    public int putStock(int stock) {
        stock = this.getStock() + stock;
        this.setStock(stock);
        return stock;
    }

    public int takeStock(int stock) throws StockInsuficientException {
        stock = this.getStock() - stock;
        if(stock > 0){
            this.setStock(stock);
        } else{
            throw new StockInsuficientException("You can't take more stock than it is");
        }
        this.setStock(stock);
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    @Override
    public String toString() {
        return "Producte [idproducte=" + idproduct + ", nom=" + name + ", preuVenda=" + priceSell + ", stock=" + stock
                + "]";
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Product) {
            Product p = (Product) obj;
            if (p.getName() == this.getName()) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }

}
