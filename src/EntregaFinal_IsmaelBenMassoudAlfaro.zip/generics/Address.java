package generics;

public class Address {
    private int pc;
    private String city;
    private String province;
    private String street;

    public Address() {
    }

    public Address(int cp, String stree, String cit, String provinc) {
        this.pc = cp;
        this.street = stree;
        this.city = cit;
        this.province = provinc;
    }

    public void setCp(int cp) {
        this.pc = cp;
    }

    public void setDomicili(String stree) {
        this.street = stree;
    }

    public void setPoblacio(String cit) {
        this.city = cit;
    }

    public void setProvincia(String provinc) {
        this.province = provinc;
    }

    public int getCp() {
        return pc;
    }

    public String getDomicili() {
        return street;
    }

    public String getPoblacio() {
        return city;
    }

    public String getProvincia() {
        return province;
    }

    @Override
    public String toString() {
        return "Adreca [cp=" + pc + ", domicili=" + street + ", poblacio=" + city + ", provincia=" + province
                + "]";
    }
}
