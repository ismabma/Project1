package generics;

public interface Identificable {
    public Integer getId();
}
