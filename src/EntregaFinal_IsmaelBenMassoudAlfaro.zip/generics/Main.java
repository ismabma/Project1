package generics;

import java.time.LocalDate;
import java.util.Scanner;

public class Main<T> {
    public static void main(String[] args) {
        menu();
    }

    private static void menu() {
        Scanner scanner = new Scanner(System.in);
        char option = 't';

        do {
            System.out.println("######################## MENU DE INICI ########################");
            System.out.println("a)MENU DE CLIENTS");
            System.out.println("b)MENU DE PROVEIDORS");
            System.out.println("c)MENU DE PRODUCTES");
            System.out.println("q)Sortir del programa");
            System.out.print("Introdueix la teva opcio: ");
            option = scanner.nextLine().charAt(0);
            switch (option) {
            case 'a':
                menuClient();
                break;
            case 'b':
                menuSupplier();
                break;
            case 'c':
                menuProducte();
                break;
            case 'q':
                System.out.println("Que la fuerza te acompañe joven padawan");
                break;
            default:
                System.out.println("Eso no tiene ningun sentido!");
                break;
            }

        } while (option != 'q');
        scanner.close();
    }

    private static void menuClient() {
        Scanner scanner = new Scanner(System.in);
        char opcion = 't';
        AbstractDAO<Client> clients = new AbstractDAO<Client>();
        Integer idpersona;
        String DNI;
        String name;
        String lastName;
        String date;
        LocalDate birthDate;
        String email;
        int tlf;
        Address adress = new Address();

        do {
            System.out.println("######################## MENU DE GESTIO DE CLIENTS ########################");
            System.out.println("a)Afegir un client");
            System.out.println("b)Actualitzar un client");
            System.out.println("c)Cercar un client");
            System.out.println("d)Esborrar un client");
            System.out.println("e)Mostrar els clients");
            System.out.println("q)Sortir del programa");
            System.out.print("Introdueix la teva opcio: ");
            opcion = scanner.nextLine().charAt(0);
            switch (opcion) {
            case 'a':
                System.out.println("Introdueix l'id:");
                idpersona = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Introdueix el nom:");
                name = scanner.nextLine();
                System.out.println("Introdueix els cognoms:");
                lastName = scanner.nextLine();
                System.out.println("Introdueix la data de naixement: (YYYY-MM-DD)");
                date = scanner.nextLine();
                birthDate = LocalDate.parse(date);
                System.out.println("Introdueix l'email:");
                email = scanner.nextLine();
                System.out.println("Introdueix el DNI:");
                DNI = scanner.nextLine();
                System.out.println("Introdueix el tlf:");
                tlf = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Introdueix el codi postal:");
                adress.setCp(scanner.nextInt());
                scanner.nextLine();
                System.out.println("Introdueix el Poblacio:");
                adress.setPoblacio(scanner.nextLine());
                System.out.println("Introdueix el Domicili:");
                adress.setDomicili(scanner.nextLine());
                System.out.println("Introdueix el Provincia:");
                adress.setProvincia(scanner.nextLine());
                Client c = new Client(idpersona, DNI, name, lastName, birthDate, email, tlf, adress);

                clients.save(c);
                break;
            case 'b':
                System.out.println("Introdueix l'id:");
                idpersona = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Introdueix el nom:");
                name = scanner.nextLine();
                System.out.println("Introdueix els cognoms:");
                lastName = scanner.nextLine();
                System.out.println("Introdueix la data de naixement: (YYYY-MM-DD)");
                date = scanner.nextLine();
                birthDate = LocalDate.parse(date);
                System.out.println("Introdueix l'email:");
                email = scanner.nextLine();
                System.out.println("Introdueix el DNI:");
                DNI = scanner.nextLine();
                System.out.println("Introdueix el tlf:");
                tlf = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Introdueix el codi postal:");
                adress.setCp(scanner.nextInt());
                scanner.nextLine();
                System.out.println("Introdueix el Poblacio:");
                adress.setPoblacio(scanner.nextLine());
                System.out.println("Introdueix el Domicili:");
                adress.setDomicili(scanner.nextLine());
                System.out.println("Introdueix el Provincia:");
                adress.setProvincia(scanner.nextLine());
                c = new Client(idpersona, DNI, name, lastName, birthDate, email, tlf, adress);

                clients.update(c);
                break;
            case 'c':
                System.out.println("Introdueix l'id:");
                idpersona = scanner.nextInt();
                scanner.nextLine();

                clients.get(idpersona);
                break;
            case 'd':
                System.out.println("Introdueix l'id:");
                idpersona = scanner.nextInt();
                scanner.nextLine();
                clients.delete(idpersona);
                break;
            case 'e':
                Persistable<Client> per = clients;
                printMap(per);
                break;
            default:
                System.out.println("Eso no tiene ningun sentido!");
                break;
            }

        } while (opcion != 'q');

        scanner.close();
    }

    private static void menuSupplier() {
        Scanner scanner = new Scanner(System.in);
        char option = 't';
        AbstractDAO<Supplier> suppliers = new AbstractDAO<Supplier>();
        Integer idperson;
        String DNI;
        String name;
        String lastName;
        String date;
        LocalDate birthDate;
        String email;
        int tlf;
        Address address = new Address();

        do {
            System.out.println("######################## MENU DE GESTIO DE PROVEIDORS ########################");
            System.out.println("a)Afegir un proveidor");
            System.out.println("b)Actualitzar un proveidor");
            System.out.println("c)Cercar un proveidor");
            System.out.println("d)Esborrar un proveidor");
            System.out.println("e)Mostrar els proveidor");
            System.out.println("q)Sortir del programa");
            System.out.print("Introdueix la teva opcio: ");
            option = scanner.nextLine().charAt(0);
            switch (option) {
            case 'a':
                System.out.println("Introdueix l'id:");
                idperson = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Introdueix el nom:");
                name = scanner.nextLine();
                System.out.println("Introdueix els cognoms:");
                lastName = scanner.nextLine();
                System.out.println("Introdueix la data de naixement: (YYYY-MM-DD)");
                date = scanner.nextLine();
                birthDate = LocalDate.parse(date);
                System.out.println("Introdueix l'email:");
                email = scanner.nextLine();
                System.out.println("Introdueix el DNI:");
                DNI = scanner.nextLine();
                System.out.println("Introdueix el tlf:");
                tlf = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Introdueix el codi postal:");
                address.setCp(scanner.nextInt());
                scanner.nextLine();
                System.out.println("Introdueix el Poblacio:");
                address.setPoblacio(scanner.nextLine());
                System.out.println("Introdueix el Domicili:");
                address.setDomicili(scanner.nextLine());
                System.out.println("Introdueix el Provincia:");
                address.setProvincia(scanner.nextLine());
                Supplier s = new Supplier(idperson, DNI, name, lastName, birthDate, email, tlf, address);

                suppliers.save(s);
                break;
            case 'b':
                System.out.println("Introdueix l'id:");
                idperson = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Introdueix el nom:");
                name = scanner.nextLine();
                System.out.println("Introdueix els cognoms:");
                lastName = scanner.nextLine();
                System.out.println("Introdueix la data de naixement: (YYYY-MM-DD)");
                date = scanner.nextLine();
                birthDate = LocalDate.parse(date);
                System.out.println("Introdueix l'email:");
                email = scanner.nextLine();
                System.out.println("Introdueix el DNI:");
                DNI = scanner.nextLine();
                System.out.println("Introdueix el tlf:");
                tlf = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Introdueix el codi postal:");
                address.setCp(scanner.nextInt());
                scanner.nextLine();
                System.out.println("Introdueix el Poblacio:");
                address.setPoblacio(scanner.nextLine());
                System.out.println("Introdueix el Domicili:");
                address.setDomicili(scanner.nextLine());
                System.out.println("Introdueix el Provincia:");
                address.setProvincia(scanner.nextLine());
                s = (Supplier) new Supplier(idperson, DNI, name, lastName, birthDate, email, tlf, address);

                suppliers.update(s);
                break;
            case 'c':
                System.out.println("Introdueix l'id:");
                idperson = scanner.nextInt();
                scanner.nextLine();

                suppliers.get(idperson);
                break;
            case 'd':
                System.out.println("Introdueix l'id:");
                idperson = scanner.nextInt();
                scanner.nextLine();
                suppliers.delete(idperson);
                break;
            case 'e':
                Persistable<Supplier> per = suppliers;
                printMap(per);
                break;
            default:
                System.out.println("Eso no tiene ningun sentido!");
                break;
            }

        } while (option != 'q');

        scanner.close();
    }

    private static void menuProducte() {
        Scanner scanner = new Scanner(System.in);
        char option = 't';
        AbstractDAO<Product> products = new AbstractDAO<Product>();
        Integer idproduct = 0;
        String name = " ";
        double priceSell = 0;
        int stock = 0;
        int discount = 0;
        String pop = " ";

        do {
            System.out.println("######################## MENU DE GESTIO DE PRODUCTES ########################");
            System.out.println("a)Afegir un producte o un pack");
            System.out.println("b)Actualitzar un producte o un pack");
            System.out.println("c)Cercar un producte o un pack");
            System.out.println("d)Esborrar un producte o un pack");
            System.out.println("e)Mostrar els productes i els packs");
            System.out.println("q)Sortir del programa");
            System.out.print("Introdueix la teva opcio: ");
            option = scanner.nextLine().charAt(0);
            switch (option) {
            case 'a':
                System.out.println("Introdueix l'id:");
                idproduct = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Introdueix el nom:");
                name = scanner.nextLine();
                System.out.println("Introdueix el preu de venta:");
                priceSell = scanner.nextDouble();
                scanner.nextLine();
                System.out.println("Introdueix l'stock:");
                stock = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Es un 'pack' o un 'producte'?");
                pop = scanner.nextLine();
                if (pop.equals("pack")) {
                    System.out.println("Introdueix el descompte:");
                    discount = scanner.nextInt();
                    scanner.nextLine();
                }

                if (pop.equals("pack")) {
                    Pack pa = new Pack(idproduct, name, priceSell, stock, discount);
                    products.save(pa);
                } else {
                    Product p = new Product(idproduct, name, priceSell, stock);
                    products.save(p);
                }
                break;
            case 'b':
                System.out.println("Introdueix l'id:");
                idproduct = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Introdueix el nom:");
                name = scanner.nextLine();
                System.out.println("Introdueix el preu de venta:");
                priceSell = scanner.nextDouble();
                scanner.nextLine();
                System.out.println("Introdueix l'stock:");
                stock = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Es un 'pack' o un 'producte'?");
                pop = scanner.nextLine();
                if (pop.equals("pack")) {
                    System.out.println("Introdueix el descompte:");
                    discount = scanner.nextInt();
                    scanner.nextLine();
                }

                if (pop.equals("pack")) {
                    Pack pa = new Pack(idproduct, name, priceSell, stock, discount);
                    products.update(pa);
                } else {
                    Product p = new Product(idproduct, name, priceSell, stock);
                    products.update(p);
                }
                break;
            case 'c':
                System.out.println("Introdueix l'id:");
                idproduct = scanner.nextInt();
                scanner.nextLine();

                products.get(idproduct);
                break;
            case 'd':
                System.out.println("Introdueix l'id:");
                idproduct = scanner.nextInt();
                scanner.nextLine();
                products.delete(idproduct);
                break;
            case 'e':
                Persistable<Product> per = products;
                printMap(per);
                break;
            default:
                System.out.println("Eso no tiene ningun sentido!");
                break;
            }

        } while (option != 'q');

        scanner.close();

    }

    private static <T> void printMap(Persistable<T> map) {
        System.out.println(map.getMap().toString());
    }

}
