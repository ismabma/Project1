package generics;

import java.util.HashMap;
import java.util.List;

public interface Persistable<T> {
    public void save(T t);

    public List<T> getAll();

    public void delete(Integer id);

    public T get(Integer id);

    public HashMap<Integer, T> getMap();
}
