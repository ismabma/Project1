import java.util.Arrays;
import java.util.Random;

public class App {
    public static void main(String[] args){

        

    }
}
