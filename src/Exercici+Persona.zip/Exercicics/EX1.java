public class EX1 {
    public static void main(String[] args) {
        System.out.println("Exercici 1");
        System.out.println("Estic estudiant a L’Institut de Badia del Vallès i estic executant amb VSCode");
    }
    
}
