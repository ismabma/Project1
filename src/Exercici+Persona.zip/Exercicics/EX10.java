import java.util.Scanner;

public class EX10 {
    public static void main(String[] args) {
        System.out.println("Exercici 10");
        Scanner teclado = new Scanner(System.in);
        int numero = Integer.parseInt(teclado.nextLine());
        teclado.close();
        for(int i = 1 ; i <= numero ; i++){
            for(int j = 1 ; j <= i ; j++){
                System.out.print("*");
            }
            System.out.println("");
        }
    }
    
}
