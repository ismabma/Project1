
public class EX11 {
    
    public static void main(String[] args) {
        System.out.println("Exercici 11");
        int[][] mat1 = new int[3][3];
        int[][] mat2 = new int[3][3];
        int[][] mat3 = new int[3][3];

        for(int i = 0;i<mat1.length;i++){
     	   for(int j = 0;j<mat1[i].length;j++){
            mat1[i][j] = (int)((Math.random()*10000)%11+5);
     	   }
        }

        for(int i = 0;i<mat2.length;i++){
     	   for(int j = 0;j<mat2[i].length;j++){
            mat2[i][j] = (int)((Math.random()*10000)%11+5);
     	   }
        } 

        for(int i = 0 ; i < mat1.length ; i++) {
            for(int j = 0 ; j < mat1.length ; j++) {
                for(int k = 0 ; k < mat1.length ; k++) {
                    mat3[i][j] += mat1[i][k]*mat2[k][j];
                }
            }
        }

        for(int i = 0;i<mat3.length;i++){
            System.out.print("| \t");
            for(int j = 0;j<mat3[i].length;j++){
            System.out.print(mat3[i][j] + "\t");
            }
            System.out.println("|");
        }



    }
    
}
