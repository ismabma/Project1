import java.util.Scanner;

public class EX12 {
    
    public static void main(String[] args) throws InterruptedException {
        System.out.println("Exercici 10");
        Scanner teclado = new Scanner(System.in);
        System.out.println("Introduce un numero grande:");
        int numero = Integer.parseInt(teclado.nextLine());
        teclado.close();
        for (int i = 0; i <= 10; i++) {
            if(i >= numero % 0.1){
                Thread.sleep(500);
                System.out.print("*");
            } else if(i >= numero % 0.2){
                Thread.sleep(500);
                System.out.print("*");
            } else if(i >= numero % 0.3){
                Thread.sleep(500);
                System.out.print("*");
            } else if(i >= numero % 0.4){
                Thread.sleep(500);
                System.out.print("*");
            } else if(i >= numero % 0.5){
                Thread.sleep(500);
                System.out.print("*");
            } else if(i >= numero % 0.6){
                Thread.sleep(500);
                System.out.print("*");
            } else if(i >= numero % 0.7){
                Thread.sleep(500);
                System.out.print("*");
            } else if(i >= numero % 0.8){
                Thread.sleep(500);
                System.out.print("*");
            } else if(i >= numero % 0.9){
                Thread.sleep(500);
                System.out.print("*");
            } else if(i == numero){
                Thread.sleep(500);
                System.out.print("*");
            }
        }
    }

}
