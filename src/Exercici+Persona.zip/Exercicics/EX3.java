public class EX3 {
    public static void main(String[] args) {
        System.out.println("Exercici 3");
        int suma = 0;
        int numero1 = 0;
        int numero2 = 100;
        for (int i = numero1; i < numero2; i++) {
            if (i % 2 != 0) {
                suma = suma + i;
            }
        }
        System.out.println(suma);


    }
    
}
