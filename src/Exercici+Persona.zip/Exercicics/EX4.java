public class EX4 {
    public static void main(String[] args) {
        System.out.println("Exercici 4");
        String cadena = "Cadena de caracteres";
        String[] cad = cadena.split("");
        for (int i = cad.length - 1; i >= 0; i--) {
            System.out.print(cad[i]);
        }
        System.out.println("");



    }
    
}
