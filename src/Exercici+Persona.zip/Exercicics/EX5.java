public class EX5 {
    public static void main(String[] args) {
        System.out.println("Exercici 5");
        StringBuilder cadenabuilder = new StringBuilder();
        cadenabuilder.append("Cadena de caracteres builder");
        String[] cadbuilder = cadenabuilder.toString().split("");
        for (int i = cadbuilder.length - 1; i >= 0; i--) {
            System.out.print(cadbuilder[i]);
        }
        System.out.println("");

    }
    
}
