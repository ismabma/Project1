import java.util.Random;

public class EX6 {
    public static void main(String[] args) {
        System.out.println("Exercici 6");
        Random random = new Random();
        int int_random = 0;
        int suma = 0;
        int array[] = new int[10];
        for (int i = 0; i < array.length; i++) {
            int_random = random.nextInt(100);
            if (int_random == 0) {
                int_random++;
            }
            array[i] = int_random;
        }
        for (int i = 0; i < array.length; i++) {
            suma = suma + i;
        }
        System.out.println("Suma: " + suma);
        System.out.println("Numero petit: " + array[0]);
        System.out.println("Numero gran: " + array[array.length-1]);

    }
    
}
