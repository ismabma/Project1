import java.util.Arrays;
import java.util.Random;

public class EX7 {
    public static void main(String[] args) {
        System.out.println("Exercici 7");
        Random randomm = new Random();
        int int_randomm = 0;
        int arrayy[] = new int[5];
        for (int i = 0; i < arrayy.length; i++) {
            int_randomm = randomm.nextInt(100);
            if (int_randomm == 0) {
                int_randomm++;
            }
            arrayy[i] = int_randomm;
        }

        boolean orden = true;
        do{
            orden = true;
            for (int i = 0; i < arrayy.length-1; i++) {
                int temp = 0;
                if(arrayy[i] > arrayy[i+1]){
                    temp = arrayy[i];
                    arrayy[i] = arrayy[i+1];
                    arrayy[i+1] = temp;
                    orden = false;
                }
            }
        }while(orden == false);
        System.out.println(Arrays.toString(arrayy));

    }
    
}
