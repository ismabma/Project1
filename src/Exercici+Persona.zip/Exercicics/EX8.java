public class EX8 {
    public static void main(String[] args) {
        System.out.println("Exercici 8");
        int numero = Integer.parseInt(args[0]);
        int factorial = 1;
        for(int i = 1 ; i <= numero ; i++){
            factorial *= i;
        }

        System.out.println("El numero factorial es: " + factorial);

    }
    
}
