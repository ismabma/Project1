import java.util.Scanner;

public class EX9 {
    public static void main(String[] args) {
        System.out.println("Exercici 9");
        Scanner teclado = new Scanner(System.in);
        int numero = Integer.parseInt(teclado.nextLine());
        teclado.close();
        int factorial = 1;
        for(int i = 1 ; i <= numero ; i++){
            factorial *= i;
        }

        System.out.println("El numero factorial es: " + factorial);

    }
    
}
