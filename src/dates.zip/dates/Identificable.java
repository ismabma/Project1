package dates;

public interface Identificable {
    public Integer getId();
}
