package errnorec;

import java.time.LocalDate;

public class Client extends Person {
    public Client(int idperson, String dNI, String name, String lastName, LocalDate birthDate, String email,
            int phone, Address adress) {
        super(idperson, dNI, name, lastName, birthDate, email, phone, adress);
    }

    public Client(int idperson, String dNI, String name, String lastName) {
        super(idperson, dNI, name, lastName);
    }
}
