package errnorec;

public interface Identificable {
    public Integer getId();
}
