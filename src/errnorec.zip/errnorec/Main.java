package errnorec;

import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main{
    /**
     * Per quan introdueix una opcio que no existeix
     */
    private static final String NONSENSE = "Eso no tiene ningun sentido!";
    /**
     * Text de introduir la teva opcio
     */
    private static final String INSERT_OPTION = "Introdueix la teva opcio: ";
    /**
     * Opcio de sortir del programa
     */
    private static final String Q_EXIT = "q)Sortir del programa";
    public static void main(String[] args) throws SecurityException, IOException{
        menu();
    }

    private static void menu() throws SecurityException, IOException {
        Handler fileHandler = new FileHandler("./dao.log", false);
        SimpleFormatter simpleFormatter = new SimpleFormatter();
        Logger logger = Logger.getLogger("DAO");
        Scanner scanner = new Scanner(System.in);
        
        fileHandler.setFormatter(simpleFormatter);
        logger.addHandler(fileHandler);
        char option = ' ';
        

            do {
                System.out.println("######################## MENU DE INICI ########################");
                System.out.println("a)MENU DE CLIENTS");
                System.out.println("b)MENU DE PROVEIDORS");
                System.out.println("c)MENU DE PRODUCTES");
                System.out.println(Q_EXIT);
                System.out.print(INSERT_OPTION);
                try {
                    option = scanner.nextLine().charAt(0);
                    switch (option) {
                    case 'a':
                        menuClient(logger);
                        break;
                    case 'b':
                        menuSupplier(logger);
                        break;
                    case 'c':
                        menuProduct(logger);
                        break;
                    case 'q':
                        System.out.println("Que la fuerza te acompañe joven padawan");
                        break;
                    default:
                        System.out.println(NONSENSE);
                        break;
                    }
                } catch (StringIndexOutOfBoundsException e) {
                    logger.info(e.toString());
                }

            } while (option != 'q');
            scanner.close();
    }

    private static void menuClient(Logger logger) {
        Scanner scanner = new Scanner(System.in);
        char opcion = ' ';
        AbstractDAO<Client> clients = new AbstractDAO<>();
        Integer idpersona;
        String dni;
        String name;
        String lastName;
        String date;
        LocalDate birthDate;
        String email;
        int tlf;
        Address adress = new Address();

        do {
            System.out.println("######################## MENU DE GESTIO DE CLIENTS ########################");
            System.out.println("a)Afegir un client");
            System.out.println("b)Actualitzar un client");
            System.out.println("c)Cercar un client");
            System.out.println("d)Esborrar un client");
            System.out.println("e)Mostrar els clients");
            System.out.println(Q_EXIT);
            System.out.print(INSERT_OPTION);
            try{
                opcion = scanner.nextLine().charAt(0);
                switch (opcion) {
                case 'a':
                    System.out.println("Introdueix l'id:");
                    try {
                        idpersona = scanner.nextInt();
                        scanner.nextLine();
                    } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                        idpersona = clients.getLastId();
                        idpersona++;
                    }
                    System.out.println("Introdueix el nom:");
                    try {
                        name = scanner.nextLine();
                    } catch (StringIndexOutOfBoundsException e) {
                        name = "Jose";
                    }
                    System.out.println("Introdueix els cognoms:");
                    try {
                        lastName = scanner.nextLine();
                    } catch (StringIndexOutOfBoundsException e) {
                        lastName = "Luis Prado";
                    }
                    System.out.println("Introdueix la data de naixement: (YYYY-MM-DD)");
                    try {
                        date = scanner.nextLine();
                        birthDate = LocalDate.parse(date);
                    } catch (DateTimeParseException e) {
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                        date = simpleDateFormat.format(new Date());
                        birthDate = LocalDate.parse(date);
                        logger.info(e.toString());
                    }
                    System.out.println("Introdueix l'email:");
                    try {
                        email = scanner.nextLine();
                    } catch (StringIndexOutOfBoundsException e) {
                        email = "raulapruebame@ibadia.cat";
                    }
                    System.out.println("Introdueix el DNI:");
                    try {
                        dni = scanner.nextLine();
                    } catch (StringIndexOutOfBoundsException e) {
                        dni = "56498062Y";
                    }
                    System.out.println("Introdueix el tlf:");
                    try {
                        tlf = scanner.nextInt();/* 
                        scanner.nextLine(); */
                    } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                        tlf = 000000000;
                    }
                    System.out.println("Introdueix el codi postal:");
                    try {
                        int cp = scanner.nextInt();
                        scanner.nextLine();
                        adress.setPc(cp);
                    } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                        adress.setPc(28211);
                    }
                    System.out.println("Introdueix el Poblacio:");
                    try {
                        String city = scanner.nextLine();
                        adress.setCity(city);
                    } catch (StringIndexOutOfBoundsException e) {
                        adress.setCity("Badia");
                    }
                    System.out.println("Introdueix el Domicili:");
                    try {
                        String street = scanner.nextLine();
                        adress.setStreet(street);
                    } catch (StringIndexOutOfBoundsException e) {
                        adress.setStreet("Calle Hola botella 321");
                    }
                    System.out.println("Introdueix el Provincia:");
                    try {
                        String province = scanner.nextLine();
                        adress.setProvince(province);
                    } catch (StringIndexOutOfBoundsException e) {
                        adress.setProvince("Barcelona");
                    }
                    Client c = new Client(idpersona, dni, name, lastName, birthDate, email, tlf, adress);

                    clients.save(c);
                    break;
                case 'b':
                    System.out.println("Introdueix l'id:");
                    try {
                        idpersona = scanner.nextInt();
                        scanner.nextLine();
                    } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                        idpersona = clients.getLastId();
                        idpersona++;
                    }
                    System.out.println("Introdueix el nom:");
                    try {
                        name = scanner.nextLine();
                    } catch (StringIndexOutOfBoundsException e) {
                        name = "Jose";
                    }
                    System.out.println("Introdueix els cognoms:");
                    try {
                        lastName = scanner.nextLine();
                    } catch (StringIndexOutOfBoundsException e) {
                        lastName = "Luis Prado";
                    }
                    System.out.println("Introdueix la data de naixement: (YYYY-MM-DD)");
                    try {
                        date = scanner.nextLine();
                        birthDate = LocalDate.parse(date);
                    } catch (DateTimeParseException e) {
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                        date = simpleDateFormat.format(new Date());
                        birthDate = LocalDate.parse(date);
                        logger.info(e.toString());
                    }
                    System.out.println("Introdueix l'email:");
                    try {
                        email = scanner.nextLine();
                    } catch (StringIndexOutOfBoundsException e) {
                        email = "raul.apruebame@ibadia.cat";
                    }
                    System.out.println("Introdueix el DNI:");
                    try {
                        dni = scanner.nextLine();
                    } catch (StringIndexOutOfBoundsException e) {
                        dni = "56498062Y";
                    }
                    System.out.println("Introdueix el tlf:");
                    try {
                        tlf = scanner.nextInt();/* 
                        scanner.nextLine(); */
                    } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                        tlf = 000000000;
                    }
                    System.out.println("Introdueix el codi postal:");
                    try {
                        int cp = scanner.nextInt();
                        scanner.nextLine();
                        adress.setPc(cp);
                    } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                        adress.setPc(28211);
                    }
                    System.out.println("Introdueix el Poblacio:");
                    try {
                        String city = scanner.nextLine();
                        adress.setCity(city);
                    } catch (StringIndexOutOfBoundsException e) {
                        adress.setCity("Badia");
                    }
                    System.out.println("Introdueix el Domicili:");
                    try {
                        String street = scanner.nextLine();
                        adress.setStreet(street);
                    } catch (StringIndexOutOfBoundsException e) {
                        adress.setStreet("Calle Hola botella 321");
                    }
                    System.out.println("Introdueix el Provincia:");
                    try {
                        String province = scanner.nextLine();
                        adress.setProvince(province);
                    } catch (StringIndexOutOfBoundsException e) {
                        adress.setProvince("Barcelona");
                    }
                    c = new Client(idpersona, dni, name, lastName, birthDate, email, tlf, adress);

                    clients.update(c);
                    break;
                case 'c':
                    System.out.println("Introdueix l'id:");
                    idpersona = scanner.nextInt();
                    scanner.nextLine();

                    clients.get(idpersona);
                    break;
                case 'd':
                    System.out.println("Introdueix l'id:");
                    idpersona = scanner.nextInt();
                    scanner.nextLine();
                    clients.delete(idpersona);
                    break;
                case 'e':
                    Persistable<Client> per = clients;
                    printMap(per);
                    break;
                default:
                    System.out.println(NONSENSE);
                    break;
                }
            
            } catch (StringIndexOutOfBoundsException e) {
                logger.info(e.toString());
            }

        } while (opcion != 'q');

        scanner.close();
    }

    private static void menuSupplier(Logger logger) {
        Scanner scanner = new Scanner(System.in);
        char option;
        AbstractDAO<Supplier> suppliers = new AbstractDAO<>();
        Integer idperson;
        String dni;
        String name;
        String lastName;
        String date;
        LocalDate birthDate;
        String email;
        int tlf;
        Address address = new Address();

        do {
            System.out.println("######################## MENU DE GESTIO DE PROVEIDORS ########################");
            System.out.println("a)Afegir un proveidor");
            System.out.println("b)Actualitzar un proveidor");
            System.out.println("c)Cercar un proveidor");
            System.out.println("d)Esborrar un proveidor");
            System.out.println("e)Mostrar els proveidor");
            System.out.println(Q_EXIT);
            System.out.print(INSERT_OPTION);
            option = scanner.nextLine().charAt(0);
            switch (option) {
            case 'a':
                System.out.println("Introdueix l'id:");
                try {
                    idperson = scanner.nextInt();
                    scanner.nextLine();
                } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                    idperson = suppliers.getLastId();
                    idperson++;
                }
                System.out.println("Introdueix el nom:");
                try {
                    name = scanner.nextLine();
                } catch (StringIndexOutOfBoundsException e) {
                    name = "Jose";
                }
                System.out.println("Introdueix els cognoms:");
                try {
                    lastName = scanner.nextLine();
                } catch (StringIndexOutOfBoundsException e) {
                    lastName = "Luis Prado";
                }
                System.out.println("Introdueix la data de naixement: (YYYY-MM-DD)");
                try {
                    date = scanner.nextLine();
                    birthDate = LocalDate.parse(date);
                } catch (DateTimeParseException e) {
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    date = simpleDateFormat.format(new Date());
                    birthDate = LocalDate.parse(date);
                    logger.info(e.toString());
                }
                System.out.println("Introdueix l'email:");
                try {
                    email = scanner.nextLine();
                } catch (StringIndexOutOfBoundsException e) {
                    email = "raulapruebame@ibadia.cat";
                }
                System.out.println("Introdueix el DNI:");
                try {
                    dni = scanner.nextLine();
                } catch (StringIndexOutOfBoundsException e) {
                    dni = "56498062Y";
                }
                System.out.println("Introdueix el tlf:");
                try {
                    tlf = scanner.nextInt();/* 
                    scanner.nextLine(); */
                } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                    tlf = suppliers.getLastId();
                    tlf++;
                }
                System.out.println("Introdueix el codi postal:");
                try {
                    int cp = scanner.nextInt();
                    scanner.nextLine();
                    address.setPc(cp);
                } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                    address.setPc(28211);
                }
                System.out.println("Introdueix el Poblacio:");
                try {
                    String city = scanner.nextLine();
                    address.setCity(city);
                } catch (StringIndexOutOfBoundsException e) {
                    address.setCity("Badia");
                }
                System.out.println("Introdueix el Domicili:");
                try {
                    String street = scanner.nextLine();
                    address.setStreet(street);
                } catch (StringIndexOutOfBoundsException e) {
                    address.setStreet("Calle Hola botella 321");
                }
                System.out.println("Introdueix el Provincia:");
                try {
                    String province = scanner.nextLine();
                    address.setProvince(province);
                } catch (StringIndexOutOfBoundsException e) {
                    address.setProvince("Barcelona");
                }
                Supplier s = new Supplier(idperson, dni, name, lastName, birthDate, email, tlf, address);

                suppliers.save(s);
                break;
            case 'b':
                System.out.println("Introdueix l'id:");
                try {
                    idperson = scanner.nextInt();
                    scanner.nextLine();
                } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                    idperson = suppliers.getLastId();
                    idperson++;
                }
                System.out.println("Introdueix el nom:");
                try {
                    name = scanner.nextLine();
                } catch (StringIndexOutOfBoundsException e) {
                    name = "Jose";
                }
                System.out.println("Introdueix els cognoms:");
                try {
                    lastName = scanner.nextLine();
                } catch (StringIndexOutOfBoundsException e) {
                    lastName = "Luis Prado";
                }
                System.out.println("Introdueix la data de naixement: (YYYY-MM-DD)");
                try {
                    date = scanner.nextLine();
                    birthDate = LocalDate.parse(date);
                } catch (DateTimeParseException e) {
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    date = simpleDateFormat.format(new Date());
                    birthDate = LocalDate.parse(date);
                    logger.info(e.toString());
                }
                System.out.println("Introdueix l'email:");
                try {
                    email = scanner.nextLine();
                } catch (StringIndexOutOfBoundsException e) {
                    email = "raulapruebame@ibadia.cat";
                }
                System.out.println("Introdueix el DNI:");
                try {
                    dni = scanner.nextLine();
                } catch (StringIndexOutOfBoundsException e) {
                    dni = "56498062Y";
                }
                System.out.println("Introdueix el tlf:");
                try {
                    tlf = scanner.nextInt();/* 
                    scanner.nextLine(); */
                } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                    tlf = suppliers.getLastId();
                    tlf++;
                }
                System.out.println("Introdueix el codi postal:");
                try {
                    int cp = scanner.nextInt();
                    scanner.nextLine();
                    address.setPc(cp);
                } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                    address.setPc(28211);
                }
                System.out.println("Introdueix el Poblacio:");
                try {
                    String city = scanner.nextLine();
                    address.setCity(city);
                } catch (StringIndexOutOfBoundsException e) {
                    address.setCity("Badia");
                }
                System.out.println("Introdueix el Domicili:");
                try {
                    String street = scanner.nextLine();
                    address.setStreet(street);
                } catch (StringIndexOutOfBoundsException e) {
                    address.setStreet("Calle Hola botella 321");
                }
                System.out.println("Introdueix el Provincia:");
                try {
                    String province = scanner.nextLine();
                    address.setProvince(province);
                } catch (StringIndexOutOfBoundsException e) {
                    address.setProvince("Barcelona");
                }
                s = new Supplier(idperson, dni, name, lastName, birthDate, email, tlf, address);

                suppliers.update(s);
                break;
            case 'c':
                System.out.println("Introdueix l'id:");
                try {
                    idperson = scanner.nextInt();
                    scanner.nextLine();
                } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                    idperson = suppliers.getLastId();
                    idperson++;
                }

                suppliers.get(idperson);
                break;
            case 'd':
                System.out.println("Introdueix l'id:");
                try {
                    idperson = scanner.nextInt();
                    scanner.nextLine();
                } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                    idperson = suppliers.getLastId();
                    idperson++;
                }
                suppliers.delete(idperson);
                break;
            case 'e':
                Persistable<Supplier> per = suppliers;
                printMap(per);
                break;
            default:
                System.out.println(NONSENSE);
                break;
            }

        } while (option != 'q');

        scanner.close();
    }

    private static void menuProduct(Logger logger) {
        Scanner scanner = new Scanner(System.in);
        char option;
        AbstractDAO<Product> products = new AbstractDAO<>();
        Integer idproduct = 0;
        String name;
        double priceSell = 0;
        int stock = 0;
        int discount = 0;
        String pop;

        do {
            System.out.println("######################## MENU DE GESTIO DE PRODUCTES ########################");
            System.out.println("a)Afegir un producte o un pack");
            System.out.println("b)Actualitzar un producte o un pack");
            System.out.println("c)Cercar un producte o un pack");
            System.out.println("d)Esborrar un producte o un pack");
            System.out.println("e)Mostrar els productes i els packs");
            System.out.println(Q_EXIT);
            System.out.print(INSERT_OPTION);
            option = scanner.nextLine().charAt(0);
            switch (option) {
            case 'a':
                System.out.println("Introdueix l'id:");
                try {
                    idproduct = scanner.nextInt();
                    scanner.nextLine();
                } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                    idproduct = products.getLastId();
                    idproduct++;
                }
                System.out.println("Introdueix el nom:");
                try {
                    name = scanner.nextLine();
                } catch (StringIndexOutOfBoundsException e) {
                    name = "Canicas";
                }
                System.out.println("Introdueix el preu de venta:");
                try {
                    priceSell = scanner.nextDouble();
                    scanner.nextLine();
                } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                    priceSell = 5;
                }
                System.out.println("Introdueix l'stock:");
                try {
                    stock = scanner.nextInt();
                    scanner.nextLine();
                } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                    stock = products.getLastId();
                    stock++;
                }
                System.out.println("Es un 'pack' o un 'producte'?");
                try {
                    pop = scanner.nextLine();
                } catch (StringIndexOutOfBoundsException e) {
                    pop = "producte";
                }
                if (pop.equals("pack")) {
                    System.out.println("Introdueix el descompte:");
                    try {
                        discount = scanner.nextInt();
                        scanner.nextLine();
                    } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                        discount = 10;
                    }
                }

                if (pop.equals("pack")) {
                    Pack pa = new Pack(idproduct, name, priceSell, stock, discount);
                    products.save(pa);
                } else {
                    Product p = new Product(idproduct, name, priceSell, stock);
                    products.save(p);
                }
                break;
            case 'b':
                System.out.println("Introdueix l'id:");
                try {
                    idproduct = scanner.nextInt();
                    scanner.nextLine();
                } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                    idproduct = products.getLastId();
                    idproduct++;
                }
                System.out.println("Introdueix el nom:");
                try {
                    name = scanner.nextLine();
                } catch (StringIndexOutOfBoundsException e) {
                    name = "Canicas";
                }
                System.out.println("Introdueix el preu de venta:");
                try {
                    priceSell = scanner.nextDouble();
                    scanner.nextLine();
                } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                    priceSell = 5;
                }
                scanner.nextLine();
                System.out.println("Introdueix l'stock:");
                try {
                    stock = scanner.nextInt();
                    scanner.nextLine();
                } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                    stock = 0;
                }
                System.out.println("Es un 'pack' o un 'producte'?");
                try {
                    pop = scanner.nextLine();
                } catch (StringIndexOutOfBoundsException e) {
                    pop = "producte";
                }
                if (pop.equals("pack")) {
                    System.out.println("Introdueix el descompte:");
                    try {
                        discount = scanner.nextInt();
                        scanner.nextLine();
                    } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                        discount = 10;
                    }
                }

                if (pop.equals("pack")) {
                    Pack pa = new Pack(idproduct, name, priceSell, stock, discount);
                    products.update(pa);
                } else {
                    Product p = new Product(idproduct, name, priceSell, stock);
                    products.update(p);
                }
                break;
            case 'c':
                try {
                    idproduct = scanner.nextInt();
                    scanner.nextLine();
                } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                    idproduct = products.getLastId();
                    idproduct++;
                }

                products.get(idproduct);
                break;
            case 'd':
                try {
                    idproduct = scanner.nextInt();
                    scanner.nextLine();
                } catch (StringIndexOutOfBoundsException | InputMismatchException e) {
                    idproduct = products.getLastId();
                    idproduct++;
                }
                products.delete(idproduct);
                break;
            case 'e':
                Persistable<Product> per = products;
                printMap(per);
                break;
            default:
                System.out.println(NONSENSE);
                break;
            }

        } while (option != 'q');

        scanner.close();

    }

    private static <T> void printMap(Persistable<T> map) {
        System.out.println(map.getMap().toString());
    }

}
