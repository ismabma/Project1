package generics;

import java.util.HashMap;

public class AbstractDAO<T> implements Persistable<T> {
    private HashMap<Integer, T> map = new HashMap<Integer, T>();

    public HashMap<Integer, T> getMap() {
        return map;
    }

    public T add(T t) {
        Client c = (Client) t;
        if (map.containsKey(c.getIdpersona()) == false) {
            this.map.put(c.getIdpersona(), t);
            return t;
        }
        return null;
    }

    public void update(T t) {
        Client c = (Client) t;
        if (map.containsKey(c.getIdpersona()) == true) {
            this.map.put(c.getIdpersona(), t);
        }
    }

    public T search(Integer idclient) {
        return this.map.get(idclient);
    }

    public T delete(Integer idclient) {
        T t = this.map.get(idclient);
        this.map.remove(idclient);
        return t;
    }
}
