package generics;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public abstract class Person {
    private Integer idperson;
    private String DNI;
    private String name;
    private String last_name;
    private LocalDate birthDate;
    private String Email;
    private int tlf;
    private Address address;
    static int num_persons;

    // Contructor 1
    public Person(Integer idperso, String dNI, String nam, String last_nam) {
        if (isValid(dNI, nam, last_nam)) {
            this.idperson = idperso;
            this.DNI = dNI;
            this.name = nam;
            this.last_name = last_nam;
            num_persons++;
        }
    }

    // Contructor 2
    public Person(Integer idperso, String dNI, String nam, String last_nam, LocalDate birthDat, String email,
            int tlf, Address address) {
        if (isValid(dNI, nam, last_nam)) {
            this.idperson = idperso;
            this.DNI = dNI;
            this.name = nam;
            this.last_name = last_nam;
            this.birthDate = birthDat;
            this.Email = email;
            this.tlf = tlf;
            this.address = address;
            num_persons++;
        }
    }

    // Setters
    public void setAdreca(Address address) {
        this.address = address;
    }

    public void setCognoms(String last_nam) {
        this.last_name = last_nam;
    }

    public void setDNI(String dNI) {
        DNI = dNI;
    }

    public void setData_naixement(LocalDate birthDat) {
        this.birthDate = birthDat;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public void setIdpersona(Integer idperso) {
        this.idperson = idperso;
    }

    public void setNom(String nam) {
        this.name = nam;
    }

    public void setTlf(int tlf) {
        this.tlf = tlf;
    }

    // Getters
    public Address getAdreca() {
        return address;
    }

    public String getCognoms() {
        return last_name;
    }

    public String getDNI() {
        return DNI;
    }

    public LocalDate getData_naixement() {
        return birthDate;
    }

    public String getEmail() {
        return Email;
    }

    public int getIdpersona() {
        return idperson;
    }

    public String getNom() {
        return name;
    }

    public int getTlf() {
        return tlf;
    }

    public int getNumPersones() {
        return num_persons;
    }

    public int getEdad() {
        return (int) ChronoUnit.YEARS.between(this.birthDate, LocalDate.now());
    }

    public static long diferenciaEdad(Person p1, Person p2) {
        return ChronoUnit.YEARS.between(p1.birthDate, p2.birthDate);
    }

    @Override
    public String toString() {
        return "ID: " + this.idperson + "\n" + "DNI: " + this.DNI + "\n" + "Email: " + this.Email + "\n" + "Cognoms: "
                + this.last_name + "\n" + "Nom: " + this.name + "\n" + "Telefon: " + this.tlf + "\n" + "Adreca: "
                + this.address.toString() + "\n" + "Edat: " + this.getEdad() + "\n";
    }

    private boolean isValid(String dNI, String nam, String last_nam) {
        if (dNI != null && nam != null && last_nam != null) {
            return true;
        } else {
            return false;
        }
    }

}
