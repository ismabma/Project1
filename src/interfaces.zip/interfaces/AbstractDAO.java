package interfaces;

import java.util.HashMap;

public class AbstractDAO implements Persistable {
    private HashMap<Integer, Object> map = new HashMap<Integer, Object>();

    public HashMap<Integer, Object> getMap() {
        return map;
    }

    public Object add(Object obj) {
        Client c = (Client) obj;
        if(map.containsKey(c.getIdpersona()) == false){
                this.map.put(c.getIdpersona(), c);
                return c;
        }
        return null;
    }

    public void update(Object obj) {
        Client c = (Client) obj;
        if(map.containsKey(c.getIdpersona()) == true){
                this.map.put(c.getIdpersona(), c);
        }
    }

    public Object search(Integer idclient) {
        return (Client) this.map.get(idclient);
    }

    public Object delete(Integer idclient) {
        Client c = (Client) this.map.get(idclient);
        this.map.remove(idclient);
        return c;
    }
}
