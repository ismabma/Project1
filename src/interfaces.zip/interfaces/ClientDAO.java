package interfaces;

import java.util.HashMap;

public class ClientDAO implements Persistable {
    private HashMap<Integer, Object> clients = new HashMap<Integer, Object>();

    public HashMap<Integer, Object> getMap() {
        return clients;
    }

    public Object add(Object obj) {
        Client c = (Client) obj;
        if(clients.containsKey(c.getIdpersona()) == false){
                this.clients.put(c.getIdpersona(), c);
                return c;
        }
        return null;
    }

    public void update(Object obj) {
        Client c = (Client) obj;
        if(clients.containsKey(c.getIdpersona()) == true){
                this.clients.put(c.getIdpersona(), c);
        }
    }

    public Object search(Integer idclient) {
        return (Client) this.clients.get(idclient);
    }

    public Object delete(Integer idclient) {
        Client c = (Client) this.clients.get(idclient);
        this.clients.remove(idclient);
        return c;
    }

    public String showClients() {
        return this.clients.toString();
    }

    public String showClient(Integer idpersona){
        return this.clients.get(idpersona).toString();
    }
}
