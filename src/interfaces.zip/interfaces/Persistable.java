package interfaces;

import java.util.HashMap;

public interface Persistable {
    public Object add(Object obj);
    public Object delete(Integer id);
    public Object search(Integer id);
    public HashMap<Integer, Object> getMap();
}
