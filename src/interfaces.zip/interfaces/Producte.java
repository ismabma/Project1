package interfaces;

public class Producte {
    private Integer idproduct;
    private String name;
    private double priceSell;
    private int stock;

    public Producte(Integer idproducte, String nom, double preuVenda, int stock) {
        this.idproduct = idproducte;
        this.name = nom;
        this.priceSell = preuVenda;
        this.stock = stock;
    }
    
    public Integer getIdproduct() {
        return idproduct;
    }

    public void setIdproduct(Integer idproducte) {
        this.idproduct = idproducte;
    }

    public String getName() {
        return name;
    }

    public void setName(String nom) {
        this.name = nom;
    }

    public double getpriceSell() {
        return priceSell;
    }

    public void setpriceSell(double preuVenda) {
        this.priceSell = preuVenda;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    @Override
    public String toString() {
        return "Producte [idproducte=" + idproduct + ", nom=" + name + ", preuVenda=" + priceSell + ", stock=" + stock + "]";
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof Producte){
            Producte p = (Producte) obj;
            if(p.getName() == this.getName()){
                return true;
            } else {
                return false;
            }
        }
        return false;
    }

}
