package interfaces;

import java.util.HashMap;

public class ProducteDAO implements Persistable {
    private HashMap<Integer, Object> products = new HashMap<Integer, Object>();

    public HashMap<Integer, Object> getMap() {
        return products;
    }

    public void setProducts(HashMap<Integer, Object> productss) {
        this.products = productss;
    }

    public Object add(Object obj) {
        Producte p = (Producte)obj;
        if(products.containsKey(p.getIdproduct()) == false){
            this.products.put(p.getIdproduct() , obj);
            return p;
        }
        return null;
    }

    public void update(Integer idproduct, String name, double priceSell, int stock, int discount, String pop) {
        Producte p = new Producte(idproduct, name, priceSell, stock);
        Pack pa = new Pack(idproduct, name, priceSell, stock, discount);
        if(products.containsKey(idproduct) == true){
            if(pop.equals("pack")){
                this.products.put(idproduct, pa);
            } else{
                this.products.put(idproduct, p);
            }
        }
    }

    public Producte search(Integer idproduct) {
        return (Producte) this.products.get(idproduct);
    }

    public Object delete(Integer idproduct) {
        Producte p = (Producte) this.products.get(idproduct);
        this.products.remove(idproduct);
        return p;
    }

    public String showProducts() {
        return this.products.toString();
    }



    
}
