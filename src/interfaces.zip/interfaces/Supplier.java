package interfaces;

import java.time.LocalDate;

public class Supplier extends Persona{

    public Supplier(int idpersona, String dNI, String nom, String cognoms, LocalDate data_naixement, String email,
            int tlf, Adreca adreca) {
        super(idpersona, dNI, nom, cognoms, data_naixement, email, tlf, adreca);
    }

    public Supplier(int idpersona, String dNI, String nom, String cognoms) {
        super(idpersona, dNI, nom, cognoms);
    }

    
}
