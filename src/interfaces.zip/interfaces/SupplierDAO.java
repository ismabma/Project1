package interfaces;

import java.util.HashMap;

public class SupplierDAO implements Persistable{
    private HashMap<Integer, Object> supplier = new HashMap<Integer, Object>();

    public HashMap<Integer, Object> getMap() {
        return supplier;
    }

    public Object add(Object obj) {
        Supplier c = (Supplier) obj;
        if(supplier.containsKey(c.getIdpersona()) == false){
                this.supplier.put(c.getIdpersona(), c);
                return c;
        }
        return null;
    }

    public void update(Object obj) {
        Supplier c = (Supplier) obj;
        if(supplier.containsKey(c.getIdpersona()) == true){
                this.supplier.put(c.getIdpersona(), c);
        }
    }

    public Object search(Integer idsupplier) {
        return (Supplier) this.supplier.get(idsupplier);
    }

    public Object delete(Integer idsupplier) {
        Supplier c = (Supplier) this.supplier.get(idsupplier);
        this.supplier.remove(idsupplier);
        return c;
    }

    public String showClients() {
        return this.supplier.toString();
    }

    public String showClient(Integer idpersona){
        return this.supplier.get(idpersona).toString();
    }
}
