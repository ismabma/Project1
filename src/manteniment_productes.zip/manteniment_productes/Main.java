package manteniment_productes;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        menu();
    }
    
    private static void menu(){
        Scanner teclado = new Scanner(System.in);
        char opcion = 't';
        ProducteDAO productes = new ProducteDAO();
        String idproduct = " ";
        String name = " ";
        double priceSell = 0;
        int stock = 0;

        do{
            System.out.println("######################## MENU DE GESTIO DE PRODUCTES ########################");
            System.out.println("a)Afegir un producte");
            System.out.println("b)Actualitzar un producte");
            System.out.println("c)Cercar un producte");
            System.out.println("d)Borrar un producte un producte");
            System.out.println("e)Mostrar els productes");
            System.out.println("q)Sortir del programa");
            System.out.print("Introdueix la teva opcio: ");
            opcion = teclado.nextLine().charAt(0);
            switch (opcion) {
                case 'a':
                    System.out.println("Introdueix id del producte:");
                    idproduct = teclado.nextLine();
                    System.out.println("Introdueix nom del producte:");
                    name = teclado.nextLine();
                    System.out.println("Introdueix preu de venta del producte:");
                    priceSell = teclado.nextDouble();
                    teclado.nextLine();
                    System.out.println("Introdueix stock del producte:");
                    stock = teclado.nextInt();
                    teclado.nextLine();

                    productes.addProduct(idproduct, name, priceSell, stock);
                    break;
                case 'b':
                    System.out.println("Introdueix id del producte:");
                    idproduct = teclado.nextLine();
                    System.out.println("Introdueix nom del producte:");
                    name = teclado.nextLine();
                    System.out.println("Introdueix preu de venta del producte:");
                    priceSell = teclado.nextDouble();
                    teclado.nextLine();
                    System.out.println("Introdueix stock del producte:");
                    stock = teclado.nextInt();
                    teclado.nextLine();
                    productes.updateProduct(idproduct, name, priceSell, stock);
                    break;
                case 'c':
                    System.out.println("Introdueix id del producte:");
                    idproduct = teclado.nextLine();
                    if(productes.searchProduct(idproduct)){
                        System.out.println(productes.showProduct(idproduct));
                    } else{
                        System.out.println("El producte no existeix!");
                    }
                    break;
                case 'd':
                    System.out.println("Introdueix id del producte:");
                    idproduct = teclado.nextLine();
                    productes.deleteProduct(idproduct);
                    break;
                case 'e':
                    System.out.println(productes.showProducts());
                    break;
                case 'q':
                    System.out.println("Que la fuerza te acompañe joven padawan");
                    break;
                default:
                System.out.println("Eso no tiene ningun sentido!");
                    break;
            }

        }while(opcion != 'q');
        
        teclado.close();
    
    }
    
}
