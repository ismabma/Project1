package manteniment_productes;

public class Producte {
    private String idproduct;
    private String name;
    private double priceSell;
    private int stock;

    public Producte(String idproducte, String nom, double preuVenda, int stock) {
        this.idproduct = idproducte;
        this.name = nom;
        this.priceSell = preuVenda;
        this.stock = stock;
    }
    
    public String getIdproduct() {
        return idproduct;
    }

    public void setIdproduct(String idproducte) {
        this.idproduct = idproducte;
    }

    public String getName() {
        return name;
    }

    public void setName(String nom) {
        this.name = nom;
    }

    public double getpriceSell() {
        return priceSell;
    }

    public void setpriceSell(double preuVenda) {
        this.priceSell = preuVenda;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    @Override
    public String toString() {
        return "Producte [idproducte=" + idproduct + ", nom=" + name + ", preuVenda=" + priceSell + ", stock=" + stock + "]";
    }
}
