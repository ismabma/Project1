package manteniment_productes;

import java.util.HashMap;

public class ProducteDAO {
    private HashMap<String, Producte> products = new HashMap<String, Producte>();

    public void addProduct(String idproduct, String name, double priceSell, int stock) {
        Producte p = new Producte(idproduct, name, priceSell, stock);
        if(products.containsKey(idproduct) == false){
            this.products.put(idproduct, p);
        }
    }

    public void updateProduct(String idproduct, String name, double priceSell, int stock) {
        Producte p = new Producte(idproduct, name, priceSell, stock);
        if(products.containsKey(idproduct) == true){
            this.products.put(idproduct, p);
        }
    }

    public boolean searchProduct(String idproduct) {
        return this.products.containsKey(idproduct);
        //TODO
    }

    public void deleteProduct(String idproduct) {
        this.products.remove(idproduct);
    }

    public String showProducts() {
        return this.products.toString();
    }

    public String showProduct(String idproduct){
        return this.products.get(idproduct).toString();
    }

    
}
