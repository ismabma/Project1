package packs_productes;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        menu();
    }
    
    private static void menu(){
        Scanner teclado = new Scanner(System.in);
        char opcion = 't';
        ProducteDAO productes = new ProducteDAO();
        Integer idproduct = 0;
        String name = " ";
        double priceSell = 0;
        int stock = 0;
        int discount = 0;
        String pop = " ";

        do{
            System.out.println("######################## MENU DE GESTIO DE PRODUCTES ########################");
            System.out.println("a)Afegir un producte o un pack");
            System.out.println("b)Actualitzar un producte o un pack");
            System.out.println("c)Cercar un producte o un pack");
            System.out.println("d)Esborrar un producte o un pack");
            System.out.println("e)Mostrar els productes i els packs");
            System.out.println("q)Sortir del programa");
            System.out.print("Introdueix la teva opcio: ");
            opcion = teclado.nextLine().charAt(0);
            switch (opcion) {
                case 'a':
                    System.out.println("Introdueix l'id:");
                    idproduct = teclado.nextInt();
                    teclado.nextLine();
                    System.out.println("Introdueix el nom:");
                    name = teclado.nextLine();
                    System.out.println("Introdueix el preu de venta:");
                    priceSell = teclado.nextDouble();
                    teclado.nextLine();
                    System.out.println("Introdueix l'stock:");
                    stock = teclado.nextInt();
                    teclado.nextLine();
                    System.out.println("Es un 'pack' o un 'producte'?");
                    pop = teclado.nextLine();
                    if(pop.equals("pack")){
                        System.out.println("Introdueix el descompte:");
                        discount = teclado.nextInt();
                        teclado.nextLine();
                    }

                    productes.addProduct(idproduct, name, priceSell, stock, discount, pop);
                    break;
                case 'b':
                    System.out.println("Introdueix l'id:");
                    idproduct = teclado.nextInt();
                    teclado.nextLine();
                    System.out.println("Introdueix el nom:");
                    name = teclado.nextLine();
                    System.out.println("Introdueix el preu de venta:");
                    priceSell = teclado.nextDouble();
                    teclado.nextLine();
                    System.out.println("Introdueix l'stock:");
                    stock = teclado.nextInt();
                    teclado.nextLine();
                    System.out.println("Es un 'pack' o un 'producte'?");
                    pop = teclado.nextLine();
                    if(pop.equals("pack")){
                        System.out.println("Introdueix el descompte:");
                        discount = teclado.nextInt();
                        teclado.nextLine();
                    }


                    productes.updateProduct(idproduct, name, priceSell, stock, discount, pop);
                    break;
                case 'c':
                    System.out.println("Introdueix l'id:");
                    idproduct = teclado.nextInt();
                    teclado.nextLine();
                    if(productes.searchProduct(idproduct)){
                        System.out.println(productes.showProduct(idproduct));
                    } else{
                        System.out.println("El producte/pack no existeix!");
                    }
                    break;
                case 'd':
                    System.out.println("Introdueix l'id:");
                    idproduct = teclado.nextInt();
                    teclado.nextLine();
                    productes.deleteProduct(idproduct);
                    break;
                case 'e':
                    System.out.println(productes.showProducts());
                    break;
                case 'q':
                    System.out.println("Que la fuerza te acompañe joven padawan");
                    break;
                default:
                System.out.println("Eso no tiene ningun sentido!");
                    break;
            }

        }while(opcion != 'q');
        
        teclado.close();
    
    }
    
}
