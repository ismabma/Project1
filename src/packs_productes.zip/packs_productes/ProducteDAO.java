package packs_productes;

import java.util.HashMap;

public class ProducteDAO {
    private HashMap<Integer, Producte> products = new HashMap<Integer, Producte>();

    public void addProduct(Integer idproduct, String name, double priceSell, int stock, int discount, String pop) {
        Producte p = new Producte(idproduct, name, priceSell, stock);
        Pack pa = new Pack(idproduct, name, priceSell, stock, discount);
        if(products.containsKey(idproduct) == false){
            if(pop.equals("pack")){
                this.products.put(idproduct, pa);
            } else{
                this.products.put(idproduct, p);
            }
        }
    }

    public void updateProduct(Integer idproduct, String name, double priceSell, int stock, int discount, String pop) {
        Producte p = new Producte(idproduct, name, priceSell, stock);
        Pack pa = new Pack(idproduct, name, priceSell, stock, discount);
        if(products.containsKey(idproduct) == true){
            if(pop.equals("pack")){
                this.products.put(idproduct, pa);
            } else{
                this.products.put(idproduct, p);
            }
        }
    }

    public boolean searchProduct(Integer idproduct) {
        return this.products.containsKey(idproduct);
    }

    public void deleteProduct(Integer idproduct) {
        this.products.remove(idproduct);
    }

    public String showProducts() {
        return this.products.toString();
    }

    public String showProduct(Integer idproduct){
        return this.products.get(idproduct).toString();
    }

    
}
